console.log("yo");
function wow() {

  hmm()
  console.log("inside yo");

  function hmm() {

    ahhh()

    console.log("inside hmm");

    function ahhh() {

      yoDawg()

      console.log("inside ahhh");

      function yoDawg() {

        console.log("inside yoDawg");

      }
    }
  }
}
wow()
console.log("taco");
