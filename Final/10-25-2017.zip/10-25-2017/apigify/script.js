// variables
var gifBtnHolder = ["turkey", "gravy", "mashed potatos"]

var btnLocationDOM = $(".button-location");
var gifImgsDOM = $("#gifImgs");

function renderBtns () {
  btnLocationDOM.empty();
  //loop over our gifBtnHolder
  for (var i = 0; i < gifBtnHolder.length; i++) {

    //generate a button to put value of newGif
    var gifyPicked = $("<button>");
    //append new gif into a button
    gifyPicked.text(gifBtnHolder[i]);
    //attr that has our btn text to get text from
    gifyPicked.attr("data-value", gifBtnHolder[i])
    //add unique identifier
    gifyPicked.attr("id", "gifBtn");

    btnLocationDOM.append(gifyPicked);
  }
}
renderBtns()



//create an onclick event to register text box and put value into a var
$("#submitBtn").on("click", function(event) {
  event.preventDefault();
  console.log(event);
  //create variable to grab value in the text box use .val .trim
  var newGif = $('#textbox').val();
  console.log(newGif);
  gifBtnHolder.push(newGif);
  console.log(gifBtnHolder);
  //this renders our new buttons
  renderBtns();
});

// api_key pGQWdSQlRqP7eqGQd1T3wreK6yBK8Aow

$(".button-location").on("click", "#gifBtn", function(){
  console.log("you clicked this btn fool!");

  var type = $(this).attr("data-value");

   var queryURL = "http://api.giphy.com/v1/gifs/search?q=" + type + "&api_key=pGQWdSQlRqP7eqGQd1T3wreK6yBK8Aow&limit=10";

   $.ajax({
     url: queryURL,
     method: "GET"
   }).done(function(response) {
     console.log(response);
     var gifArray = response.data;
     //loop over gidf array
     for (var i = 0; i < gifArray.length; i++) {
       //make image tag for each gif
       var gifImg = $("<img>");
       //show the give on the screen
       //give it a unique identifier
       gifImg.attr("id", "gif")
          //ADD THE src attribute to be teh gif url
        gifImg.attr("src", gifArray[i].images.fixed_height_still.url);
          //show that to the screen
        gifImgsDOM.prepend(gifImg)
     }
   })
})

$("#gifImgs").on("click", "#gif",  function() {
console.log("you clicked this gif fool!");
})
